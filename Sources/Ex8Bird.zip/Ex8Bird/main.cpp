#include "BirdGame.hpp"

int main(){
   new BirdGame();
   return 0;
}